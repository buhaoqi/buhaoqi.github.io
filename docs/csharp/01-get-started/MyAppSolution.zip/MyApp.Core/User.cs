namespace MyApp.Core;

public class User
{
    public string Name { get; set; } = string.Empty;
}
