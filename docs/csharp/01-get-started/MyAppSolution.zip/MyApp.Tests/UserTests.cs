using MyApp.Core;
using Xunit;

namespace MyApp.Tests;

public class UserTests
{
    [Fact]
    public void User_Name_ShouldBeSetCorrectly()
    {
        var user = new User { Name = "李四" };
        Assert.Equal("李四", user.Name);
    }
}
