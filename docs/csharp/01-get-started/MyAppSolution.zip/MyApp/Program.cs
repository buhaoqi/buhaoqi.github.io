using MyApp.Core;

Console.WriteLine("控制台主程序启动...");
var user = new User { Name = "张三" };
Console.WriteLine($"用户名称：{user.Name}");
